Jasper was originally created by Shubhro Saha and Charles Marsh in early 2014.
In August 2014, the core development team has been joined by Jan Holthuis.

    Jan Holthuis <jan.holthuis@ruhr-uni-bochum.de>
    Charles Marsh <crmarsh@princeton.edu>
    Shubhro Saha <saha@princeton.edu>

Here is a probably incomplete list of contributors, that helped to improve
Jasper. Thanks a lot!

    Alex Bate <alex@alexbate.co.uk>
    Andy Buckingham <andy@andybee.com>
    David Celis <me@davidcel.is>
    Cedric Claidiere
    dag0310
    Alex Siri
    Andrew Stahlman <andrew.stahlman@gmail.com>
    James Timmons

*Please alphabetize new entries*

We'd also like to thank all the people who reported bugs, helped
answer newbie questions, and generally made Jasper better.