"""from .knowledged import WolframAlphaPlugin"""
