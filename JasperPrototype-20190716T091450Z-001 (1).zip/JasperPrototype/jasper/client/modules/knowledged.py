# -*- coding: utf-8-*-
import random
import re
import wolframalpha
import time
import sys
from sys import maxint
from client import jasperpath
from codecs import open

WORDS = ["WHO", "WHAT", "HOW MUCH", "HOW MANY", "HOW OLD"]

PRIORITY = 3

def handle(text, mic, profile):
    app_id = profile['keys']['WOLFRAMALPHA']
    client = wolframalpha.Client(app_id)
    
    query = client.query(text)
    
    if len(list(query.pods)) > 0:
	text = ""
	pod = list(query.pods)[1]
	if pod.text:
	    texts = pod.text
	else:
	    texts = "I cannot find anything"
	
	print texts.encode('utf-8')
	"""This works fine"""
	mic.say(texts.replace("|","").encode('utf-8'))
	
	"""mic.say(text.replace("|",""))"""
    else:
	mic.say("Sorry, could you be more specific?")
	
def isValid(text):
    if re.search(r'\bwho\b', text, re.IGNORECASE):
	return True
    elif re.search(r'\bwhat\b', text, re.IGNORECASE):
	return True
    elif re.search(r'\bhow much\b', text, re.IGNORECASE):
	return True
    elif re.search(r'\bhow MANY\b', text, re.IGNORECASE):
	return True
    elif re.search(r'\bhow old\b', text, re.IGNORECASE):
	return True
    else:
	return False
