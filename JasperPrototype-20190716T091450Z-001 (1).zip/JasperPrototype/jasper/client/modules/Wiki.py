#Written by Jake Schultz
#TODO Add more lang support, limit number of results returned
import re
from urllib2 import Request, urlopen, URLError
import json, urllib

WORDS = ["WIKI", "WICKY","ARTICLE"]

PRIORITY = 1


def handle(text, mic, profile):
    # method to get the wiki summary
    get_wiki(text,mic)

"""This is where the error is
    Right now the page loads up with an empty extract
"""
def get_wiki(text,mic):
    mic.say("What would you like to learn about?")
    # get the user voice input as string
    article_title = mic.activeListen()
    lowerCaseTitle = article_title.lower()
    # make a call to the Wikipedia API    
    request = Request('https://en.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exsentences=10&exintro=&explaintext=&titles='+lowerCaseTitle)
    try:
        response = urlopen(request)
        data = json.load(response)
        # Parse the JSON to just get the extract. Always get the first summary.
        output = data["query"]["pages"]
        final = output[output.keys()[0]]["extract"]
        mic.say(final.replace("|","").encode('utf-8'))
        """mic.say(texts.replace("|","").encode('utf-8'))"""
    except URLError, e:
        mic.say("Unable to reach dictionary API.")


def isValid(text):
    wiki= bool(re.search(r'\bWiki\b',text, re.IGNORECASE))
    # Add 'Wicky' because the STT engine recognizes it quite often
    wicky= bool(re.search(r'\bwicky\b',text, re.IGNORECASE))
    article= bool(re.search(r'\barticle\b',text, re.IGNORECASE))

    if wicky or wiki or article:
        return True
    else:
        return False

