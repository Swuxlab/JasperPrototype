"""
It is an empty test as a real test requires to access SPI bus
"""


def test_pixel_ring():
    pass
