"""
snowboy as the default KWS
"""

from .kws_snowboy import KWS
